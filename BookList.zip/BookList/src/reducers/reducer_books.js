export default function() {
	return [
		{ title: 'javascript: React JS', pages: 100 },
		{ title: 'Harry Potter', pages: 20 },
		{ title: 'Komit', pages: 1 },
		{ title: "Bisnis Syar'i", pages: 1901 }
	]
}